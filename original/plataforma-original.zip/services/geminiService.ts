
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Algorithm } from '../types';

// Ensure the API key is available as an environment variable
if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getAdditionalInfo(recommendation: string): Promise<{ data: string; error: boolean }> {
  const prompt = `
    En el contexto del manejo del dolor neuropático y la farmacología, explica de forma concisa pero completa el razonamiento clínico 
    detrás de la siguiente recomendación para un profesional de la salud. 
    Tu respuesta debe ser clara, profesional y estar formateada en Markdown para fácil lectura.
    No incluyas el texto de la recomendación en tu respuesta, solo la explicación.
    
    Recomendación: "${recommendation}"
    
    Ejemplo de formato de respuesta:
    ### Razón Principal
    *   Explicación detallada del mecanismo de acción o riesgo.
    
    ### Consideraciones Adicionales
    *   Puntos secundarios o qué monitorizar.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        temperature: 0.2,
        topP: 0.95,
      }
    });
    return { data: response.text, error: false };
  } catch (error) {
    console.error("Error fetching data from Gemini API:", error);
    const errorMessage = "No se pudo obtener información adicional. Por favor, verifique su conexión o inténtelo de nuevo más tarde.";
    return { data: errorMessage, error: true };
  }
}

const algorithmSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: 'Título descriptivo del algoritmo.' },
        startStepId: { type: Type.STRING, description: 'El ID del primer paso.' },
        steps: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING, description: 'ID único para el paso (ej. "initial_assessment").' },
                    type: { type: Type.STRING, description: 'Tipo de paso: "start", "decision", "action", "end".' },
                    title: { type: Type.STRING, description: 'Título corto para el paso (ej. "Evaluar Síntomas").' },
                    text: { type: Type.STRING, description: 'Texto detallado o pregunta del paso.' },
                    options: {
                        type: Type.ARRAY,
                        description: "Opciones para los pasos de tipo 'decision'.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                text: { type: Type.STRING, description: 'Texto de la opción (ej. "Sí", "No").' },
                                nextStepId: { type: Type.STRING, description: 'ID del paso al que lleva esta opción.' },
                            },
                        },
                    },
                    nextStepId: { type: Type.STRING, description: "ID del siguiente paso para los tipos 'action' o 'start'." },
                },
                required: ['id', 'type', 'title', 'text'],
            },
        },
    },
    required: ['title', 'startStepId', 'steps'],
};

export async function generateAlgorithmFromImage(base64Image: string, mimeType: string): Promise<{ data: Algorithm | null; error: string | null }> {
    const imagePart = {
        inlineData: {
            mimeType,
            data: base64Image,
        },
    };

    const textPart = {
        text: `
            Eres un experto en informática médica. Tu tarea es analizar una imagen de un algoritmo clínico o flujograma y convertirla en un objeto JSON estructurado. El JSON debe seguir el esquema proporcionado con precisión.

            Proceso a seguir:
            1.  Identifica el punto de partida del algoritmo.
            2.  Traza cada ruta, identificando cada paso.
            3.  Clasifica cada paso como 'start', 'decision', 'action', o 'end'.
            4.  Para los pasos de 'decision', define las opciones con su texto y 'nextStepId'.
            5.  Para los pasos 'action' y 'start', define el 'nextStepId' correspondiente.
            6.  Crea un 'id' único y descriptivo para cada paso (p. ej., 'evaluacion_inicial', 'riesgo_alto', 'tratamiento_primario').
            7.  Asegúrate de que todos los 'nextStepId' se correspondan con un 'id' de paso existente.
            8.  Genera un título general para el algoritmo.
            9.  El JSON de salida debe ser válido y cumplir estrictamente con el esquema.
        `
    };

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [textPart, imagePart] },
            config: {
                responseMimeType: 'application/json',
                responseSchema: algorithmSchema,
                temperature: 0.1,
            }
        });

        // The response.text should be a JSON string that we can parse
        const jsonText = response.text.trim();
        const algorithmData = JSON.parse(jsonText) as Algorithm;
        return { data: algorithmData, error: null };

    } catch (error) {
        console.error("Error generating algorithm from image:", error);
        let errorMessage = "No se pudo interpretar el algoritmo de la imagen. Por favor, asegúrese de que la imagen sea clara y legible.";
        if (error instanceof Error && error.message.includes('SAFETY')) {
            errorMessage = "La imagen fue bloqueada por políticas de seguridad. Pruebe con una imagen diferente."
        }
        return { data: null, error: errorMessage };
    }
}