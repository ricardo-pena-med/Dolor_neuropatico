
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { ChatMessage } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { PaperAirplaneIcon } from './icons/PaperAirplaneIcon';
import { ExclamationTriangleIcon } from './icons/ExclamationTriangleIcon';
import { GUIDE_CONTENT } from '../data/guideContent';


const Markdown: React.FC<{ text: string }> = ({ text }) => {
    const html = text
      .replace(/^### (.*$)/gim, '<h3 class="text-md font-semibold text-slate-800 mt-4 mb-2">$1</h3>')
      .replace(/^\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/^\* (.*$)/gim, '<li class="ml-5 list-disc">$1</li>')
      .replace(/\n/g, '<br />');
    return <div className="prose prose-sm max-w-none text-slate-700 leading-relaxed" dangerouslySetInnerHTML={{ __html: html }} />;
};

const GuideQA: React.FC = () => {
    const [chat, setChat] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    useEffect(() => {
        // Initialize chat on component mount with pre-loaded guide content
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            const systemInstruction = `Eres un asistente médico experto y riguroso especializado en Dolor Neuropático y Fibromialgia.

            **TU PROTOCOLO DE RESPUESTA OBLIGATORIO:**

            1.  **FILTRO DE PERTINENCIA:** 
                Analiza la pregunta del usuario. ¿Está relacionada con el dolor, el dolor neuropático, su manejo, farmacología, fisiopatología o las condiciones clínicas tratadas en los artículos (diabetes, fibromialgia, etc.)?
                *   **SI LA RESPUESTA ES NO:** Debes responder EXACTAMENTE: *"Lo siento. Solo contesto preguntas directamente relacionadas con el manejo del dolor neuropático"* y detenerte ahí.

            2.  **SI LA PREGUNTA ES PERTINENTE:**
                *   Responde basándote **EXCLUSIVAMENTE** en el texto proporcionado a continuación en la sección "BASE DE CONOCIMIENTO".
                *   **CITAS:** Cada afirmación debe llevar su fuente entre paréntesis (Autor, Año). Ej: (Finnerup et al., 2015).
                *   Si la respuesta no está en los textos, indica: "La evidencia proporcionada no contiene información específica sobre este punto."
                *   Para definiciones (¿Qué es dolor?), usa la sección de "DEFINICIONES FUNDAMENTALES" o las introducciones de los artículos.
                *   Para insuficiencia renal o dosis, busca los detalles específicos en el texto.

            ---
            **BASE DE CONOCIMIENTO (ARTÍCULOS):**
            ${GUIDE_CONTENT}
            ---`;
            
            const newChat = ai.chats.create({ 
                model: 'gemini-2.5-flash', 
                config: { 
                    systemInstruction,
                    temperature: 0.1, // Muy baja temperatura para máxima precisión
                } 
            });

            setChat(newChat);
            setMessages([{
                role: 'model',
                text: 'Hola. Soy tu asistente especializado en guías clínicas (AAN, EULAR, NeuPSIG). Hazme preguntas sobre definiciones, tratamientos o dosis y responderé basándome estrictamente en la evidencia cargada.'
            }]);
        } catch (e) {
            console.error("Error initializing Gemini Chat:", e);
            setError("No se pudo iniciar el chat. Verifica la configuración de la API.");
        }
    }, []);

    const handleSendMessage = async () => {
        if (!userInput.trim() || isLoading || !chat) return;

        const currentInput = userInput;
        setUserInput('');
        setIsLoading(true);
        
        setMessages(prev => [...prev, { role: 'user', text: currentInput }]);
        setMessages(prev => [...prev, { role: 'model', text: '' }]);

        try {
            const stream = await chat.sendMessageStream({ message: currentInput });
            let modelResponse = '';

            for await (const chunk of stream) {
                modelResponse += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: 'model', text: modelResponse };
                    return newMessages;
                });
            }
        } catch (error) {
            console.error("Error sending message:", error);
            const errorMessage = "Lo siento, ha ocurrido un error al procesar tu pregunta.";
             setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1] = { role: 'model', text: errorMessage };
                return newMessages;
            });
        } finally {
            setIsLoading(false);
        }
    };
    
    if (error) {
         return (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 p-6 max-w-4xl mx-auto text-center">
                 <div className="flex flex-col items-center justify-center p-10 space-y-3 text-red-600 bg-red-50 rounded-lg">
                    <ExclamationTriangleIcon className="w-8 h-8" />
                    <p className="font-medium">Error de Inicialización</p>
                    <p className="text-sm text-red-500">{error}</p>
                </div>
            </div>
         )
    }

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200/80 max-w-4xl mx-auto flex flex-col h-[75vh]">
            <div className="p-4 border-b border-slate-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-blue-900 flex items-center gap-2">
                    <div className="bg-red-700 text-white p-1.5 rounded-full">
                        <SparklesIcon className="w-5 h-5"/>
                    </div>
                    <span>Asistente de Evidencia Clínica (AAN, EULAR, NeuPSIG)</span>
                </h2>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-2xl p-3 rounded-lg shadow-sm ${msg.role === 'user' ? 'bg-blue-800 text-white' : 'bg-white text-slate-800 border border-slate-100'}`}>
                           {msg.role === 'user' ? (
                                <p className="text-sm">{msg.text}</p>
                           ) : (
                                <Markdown text={msg.text} />
                           )}
                           {isLoading && msg.role === 'model' && index === messages.length -1 && (
                               <div className="w-2 h-2 bg-blue-800 rounded-full animate-pulse mt-2"></div>
                           )}
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-slate-200 bg-white rounded-b-xl">
                <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}>
                    <div className="relative">
                        <input
                            type="text"
                            value={userInput}
                            onChange={(e) => setUserInput(e.target.value)}
                            placeholder="Ej: ¿Qué es el dolor neuropático? ¿Cómo ajusto la pregabalina en falla renal?"
                            disabled={isLoading || !chat}
                            className="w-full pr-12 pl-4 py-2.5 border border-slate-300 rounded-full shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            aria-label="Entrada de pregunta"
                        />
                        <button
                            type="submit"
                            disabled={isLoading || !userInput.trim() || !chat}
                            className="absolute inset-y-0 right-0 flex items-center justify-center w-10 h-10 m-1 rounded-full bg-blue-800 text-white hover:bg-blue-900 disabled:bg-slate-400 disabled:cursor-not-allowed"
                            aria-label="Enviar pregunta"
                        >
                            <PaperAirplaneIcon className="w-5 h-5"/>
                        </button>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 text-center">
                        El asistente responderá preguntas sobre dolor basándose únicamente en las guías proporcionadas.
                    </p>
                </form>
            </div>
        </div>
    );
};

export default GuideQA;
